<?php 

	$servername = "localhost"; 
	$username = "root"; 
	$password = ""; 
 
$conn0 = mysqli_connect($servername, $username, $password); 

?> 
