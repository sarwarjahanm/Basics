
<!doctype html> 
	
<html lang="en"> 

<head> 
<title>SETUP-Basics</title>
<link rel="icon" type="image/x-icon" href="favicon.ico">	
	<!-- Required meta tags --> 
	<meta charset="utf-8"> 
	<meta name="viewport" content= 
		"width=device-width, initial-scale=1, 
		shrink-to-fit=no"> 
	
</head> 
	<script>
function home() {
  location.replace("http://localhost:81/Basics/Home.html")
}
</script>
	
<body style="background-image: url(http://localhost:81/VSocial/dash.jpg); background-position: center"> 
<button onclick="home()">Home Page</button><div style="text-align:center;"><h3>InfoSecCamp-Basics Setup Page</h3><br/><br/></div> <br/><br/><br/><br/><br/><br/><br/>

<div style="text-align:center;">
	
	<form action="SETUP.php" method="post"> 
		<div>
			<input type="submit" id="DBsetup" name="DBsetup" value="Setup Database"/>
		</div> 	 
	</form> <br/><br/><br/>
</div> 
	
</body> 
</html> 

<?php 

$showError = false; 
$exists=false; 
	
if($_SERVER["REQUEST_METHOD"] == "POST") { 
	
	include 'dbsetup.php'; 
	
	//Create Basics Database
	$sql0 = "create database basics";
	$result0 = mysqli_query($conn0, $sql0);
	
	$database = "basics";
	$conn1 = mysqli_connect($servername, $username, $password, $database); 
	
	//Create Tables	in Basics Database		
	$sql1 = "CREATE TABLE jsdemo(fname VARCHAR(50),lname VARCHAR(50),address VARCHAR(250),phone VARCHAR(30));CREATE TABLE dbdemo(fname VARCHAR(50),lname VARCHAR(50),address VARCHAR(250),phone VARCHAR(30));CREATE TABLE md5(username VARCHAR(50),password VARCHAR(100));CREATE TABLE aes(username VARCHAR(50),pwd VARCHAR(128),enckey VARCHAR(20),ivlen VARCHAR(100),iv VARCHAR(100),cipher VARCHAR(30),tag VARCHAR(30));CREATE TABLE plaintext(username VARCHAR(50),password VARCHAR(100));CREATE TABLE sha1(username VARCHAR(50),password VARCHAR(100));CREATE TABLE sha512(username VARCHAR(50),password VARCHAR(128));CREATE TABLE sha512salt(username VARCHAR(50),password VARCHAR(128),salt VARCHAR(10));CREATE TABLE blvalidation(fname VARCHAR(50),lname VARCHAR(5),address VARCHAR(250),phone VARCHAR(30));CREATE TABLE jsvalidation(fname VARCHAR(50),lname VARCHAR(5),address VARCHAR(250),phone VARCHAR(30));CREATE TABLE novalidation(fname VARCHAR(50),lname VARCHAR(5),address VARCHAR(250),phone VARCHAR(30));CREATE TABLE wlvalidation(fname VARCHAR(50),lname VARCHAR(5),address VARCHAR(250),phone VARCHAR(30));";
	
	$result1 = mysqli_multi_query($conn1, $sql1);
	
	while(mysqli_more_results($conn1))
		{
			mysqli_next_result($conn1);
		}
	
	$showError = "InfoSecCamp Basics database setup successful!";
}
	
?>

<?php 
	
	if($showError) { 
	
		echo ' <div style="text-align:center;" class="alert alert-danger 
			alert-dismissible fade show" role="alert"> 
		'. $showError.'
	
	<button type="button" class="close"
			data-dismiss="alert aria-label="Close"> 
			<span aria-hidden="true">�</span> 
	</button> 
	</div> '; 
} 
		
	if($exists) { 
		echo ' <div style="text-align:right;" class="alert alert-danger 
			alert-dismissible fade show" role="alert"> 
	
		<strong>Error!</strong> '. $exists.'
		<button type="button" class="close"
			data-dismiss="alert" aria-label="Close"> 
			<span aria-hidden="true">�</span> 
		</button> 
	</div> '; 
	} 

?> 