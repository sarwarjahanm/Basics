
<!doctype html> 
	
<html lang="en"> 

<head> 
<title>RESET-InfoSecCamp Basics</title>
<link rel="icon" type="image/x-icon" href="favicon.ico">	
	<!-- Required meta tags --> 
	<meta charset="utf-8"> 
	<meta name="viewport" content= 
		"width=device-width, initial-scale=1, 
		shrink-to-fit=no"> 
	
</head> 
	<script>
function home() {
  location.replace("http://localhost:81/Basics/Home.html")
}
</script>
	
<body style="background-image: url(http://localhost:81/VSocial/dash.jpg); background-position: center"> 
<button onclick="home()">Home Page</button><div style="text-align:center;"><h3>InfoSecCamp Basics - RESET DB Page</h3><br/><br/></div> <br/><br/><br/><br/><br/><br/><br/>

<div style="text-align:center;">
	
	<form action="RESET.php" method="post"> 
		<div>
			<input type="submit" id="DBreset" name="DBreset" value="Reset Database"/>
		</div> 	 
	</form> 
</div> 
	
</body> 
</html> 

<?php 

$showError = false; 
$exists=false; 


	
if($_SERVER["REQUEST_METHOD"] == "POST") { 
	
	include 'dbsetup.php';
	$database = "basics";
	$conn1 = mysqli_connect($servername, $username, $password, $database); 
		
		
		$sql3 = "DELETE FROM jsdemo;DELETE FROM dbdemo;DELETE FROM aes;DELETE FROM blvalidation;DELETE FROM jsvalidation;DELETE FROM md5;DELETE FROM novalidation;DELETE FROM plaintext;DELETE FROM sha1;DELETE FROM sha512;DELETE FROM sha512salt;DELETE FROM wlvalidation;";
		
		$result3 = mysqli_multi_query($conn1, $sql3); 
		
		$showError = "DATA hard reset successful.";
		
		while(mysqli_more_results($conn1))
		{
			mysqli_next_result($conn1);
		}
	
		
}
	
?>

<?php 
	
	if($showError) { 
	
		echo ' <br/><div style="text-align:center;" class="alert alert-danger 
			alert-dismissible fade show" role="alert"> 
		'. $showError.'
	
	<button type="button" class="close"
			data-dismiss="alert aria-label="Close"> 
			<span aria-hidden="true">�</span> 
	</button> 
	</div> '; 
} 
		
	if($exists) { 
		echo ' <div style="text-align:right;" class="alert alert-danger 
			alert-dismissible fade show" role="alert"> 
	
		<strong>Error!</strong> '. $exists.'
		<button type="button" class="close"
			data-dismiss="alert" aria-label="Close"> 
			<span aria-hidden="true">�</span> 
		</button> 
	</div> '; 
	} 

?> 